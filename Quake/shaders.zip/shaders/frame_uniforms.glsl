#ifndef FRAME_UNIFORMS_GLSL
#define FRAME_UNIFORMS_GLSL

#define SHADOW_DLIGHT_MAX 4

layout(std140, binding=0) uniform FrameDataUBO
{
        mat4    ViewProj;
        mat4    PrevViewProj;
        mat4    View;
        vec4    Fog;
        vec4    SkyFog;
        vec3    WindDir;
        float   WindPhase;
        float   ScreenDither;
        float   TextureDither;
        float   Overbright;
        float   _Pad0;
        vec3    EyePos;
        float   Time;
        vec3    PrevEyePos;
        float   DeltaTime;
        float   ZLogScale;
        float   ZLogBias;
        vec4    LightmapParams;
        vec4    LightgridParams;
        vec4    ClusteredLightParams;
        vec4    ColorSpaceParams;
        vec4    ShaderParams;
        vec4    LightingParams;
        mat4    ShadowViewProj;
        vec4    ShadowParams;
        vec4    ShadowDebug;
        vec4    ShadowSunDir;
        mat4    ShadowClusteredLightViewProj[SHADOW_DLIGHT_MAX];
        vec4    ShadowClusteredLightAtlas[SHADOW_DLIGHT_MAX];
        vec4    ShadowClusteredLightInfo[SHADOW_DLIGHT_MAX];
        vec4    ShadowClusteredLightParams;
        uint    NumLights;
        uint    PrevFrameValid;
        uint    _Pad1;
        uint    _Pad2;
};

#endif // FRAME_UNIFORMS_GLSL
